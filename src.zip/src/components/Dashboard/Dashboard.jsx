import {StyleSheet, Text, View} from 'react-native';
import Feather from 'react-native-vector-icons/Feather';
import EvilIcons from 'react-native-vector-icons/EvilIcons';
import Ionicons from 'react-native-vector-icons/Ionicons';
import Color from 'react-native-material-color';
import React from 'react';

const Dashboard = () => {
  return (
    <View style={styles.profileContainer}>
      <View style={styles.coverContent}>
        <View style={styles.IconCover} />
        <Text style={styles.profileName}>Klaytn</Text>
      </View>
      <View style={styles.underline} />
    </View>
  );
};

export default Dashboard;

const styles = StyleSheet.create({
  profileContainer: {
    flex: 1,
    paddingTop: 70,
    position: 'absolute',
  },
  coverContent: {
    borderWidth: 0,
    marginVertical: 20,
    marginHorizontal: 20,
    flexDirection: 'row',
    paddingTop: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },
  IconCover: {
    borderWidth: 1,
    marginLeft: 10,
    width: 30,
    height: 30,
    borderRadius: 25,
    backgroundColor: Color.GREY[800],
  },
  iconCoverStyle: {
    paddingLeft: 11,
    paddingTop: 20,
  },
  profileName: {
    paddingLeft: 15,
    fontSize: 15,
    fontWeight: 'bold',
    paddingTop: 5,
  },
  underline: {
    flex: 1,
    height: 2,
    backgroundColor: '#6F64FF',
    justifyContent: 'center',
    alignItems: 'center',
  },
});
