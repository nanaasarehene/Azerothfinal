import {StyleSheet, Text, View, Image, TouchableOpacity} from 'react-native';
import React from 'react';
import {Header} from '@rneui/themed';
import Color from 'react-native-material-color';
import Feather from 'react-native-vector-icons/Feather';
import Ionicons from 'react-native-vector-icons/Ionicons';

const AppHeader = props => {
  return (
    <View style={styles.container}>
      <TouchableOpacity>
        <Image
          source={require('./../../assets/icons/left-arrow.png')}
          style={styles.arrowBack}
        />
      </TouchableOpacity>
    </View>
  );
};

export default AppHeader;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 58,
    left: 16,
  },
  arrowBack: {
    Width: 24,
    Height: 24,
  },

});
