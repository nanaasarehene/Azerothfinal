import {StyleSheet, Text, View, Image} from 'react-native';
import React from 'react';
import Ionicons from 'react-native-vector-icons/Ionicons';
import Color from 'react-native-material-color';

const Profile = () => {
  return (
    <View style={styles.container}>
      <View style={styles.profileContent}>
        <View style={styles.profileIcon}>
          <Image
            source={require('./../../assets/icons/profile.png')}
            style={styles.profile}
          />
        </View>
        <Text style={styles.text}>Klaytn</Text>
      </View>
      <View style={styles.line} />
    </View>
  );
};

export default Profile;

const styles = StyleSheet.create({
  container: {
    width: 375,
    height: 40,
    top: 40,
    flex: 1,
  },
  profileContent: {
    width: 375,
    height: 40,
    flexDirection: 'row',
  },
  profileIcon: {
    left: 16,
    borderWidth: 1,
    marginLeft: 10,
    width: 30,
    height: 30,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    borderColor: '#E7E8E9',
  },
  text: {
    left: 30,
    fontSize: 16,
    fontWeight: 'bold',
    top: 5,
  },
  profile: {
    width: 20,
    height: 20,
  },
  line: {
        borderBottomColor: '#6F64FF',
        borderBottomWidth: 1,
        marginVertical: 10,
        left: 16,
        width: 343,
        height: 10,
  },
});
