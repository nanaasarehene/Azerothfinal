import {StyleSheet, View, TouchableOpacity, Image} from 'react-native';
import React, {useState} from 'react';
import {Input} from '@rneui/themed';

interface AddressInputProps {
  onChange: (text: string) => void;
}

const AddressInputComponent: React.FC<AddressInputProps> = ({onChange}) => {
  const [address, setAddress] = useState('');

  const handleInputChange = (text: string) => {
    setAddress(text);
    onChange(text);
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity>
        <Input
          placeholder="받을 친구의 지갑 주소 입력"
          value={address}
          onChangeText={handleInputChange}
          style={styles.input}
        />
      </TouchableOpacity>
      <TouchableOpacity>
        <Image
          source={require('../../assets/icons/group.png')}
          style={styles.icon}
        />
        <Image
          source={require('../../assets/icons/scan.png')}
          style={styles.icon}
        />
      </TouchableOpacity>
    </View>
  );
};

export default AddressInputComponent;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: 30,
    paddingHorizontal: 16,
    justifyContent: 'center',
    marginBottom: 16,
  },

  input: {
    width: 343,
    height: 52,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F8FAFB',
    borderWidth: 0.17,
    borderRadius: 6,
    margin: 30,
    paddingVertical: 10,
    paddingHorizontal: 12,
    fontSize: 16,
  },
  icon: {
    width: 20,
    height: 20,
    marginTop: 10,
    marginLeft: 40,
    margin: -30,
    justifyContent: 'center',
    alignItems: 'center',
    opacity: 1,
  },
});
