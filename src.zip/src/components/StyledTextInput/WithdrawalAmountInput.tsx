import {View, Text, TouchableOpacity, StyleSheet} from 'react-native';
import React, {useState} from 'react';
import {Input} from '@rneui/themed';

interface WithdrawalAmountInputProps {
  onNumberChange: (text: string) => void;
}

const WithdrawalAmountInput: React.FC<WithdrawalAmountInputProps> = ({
  onNumberChange,
}) => {
  const [number, setNumber] = useState('');
  const [amount, setAmount] = useState(0);

  const handleNumberChange = (text: string) => {
    setNumber(text);
    onNumberChange(text);
    setAmount(parseInt(text, 10));
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.inputContainer}>
        <Input
          placeholder="0 "
          keyboardType="numeric"
          value={number}
          onChangeText={handleNumberChange}
          style={styles.input}
        />
      </TouchableOpacity>
      <Text style={styles.textLabel}>출금 가능 100 KLAY</Text>
    </View>
  );
};

export default WithdrawalAmountInput;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 16,
    marginHorizontal: 40,
    justifyContent: 'center',

  },
  inputContainer: {
    width: 343,
    height: 52,
    borderWidth: 1,
    flexDirection: 'row',
    borderColor: 'gray',
    borderRadius: 6,
    padding: 8,
    margin: 30,
    alignItems: 'center',
    left: 1,
  },

  input: {
    width: 196,
    height: 48,
    left: 146,
  },
  textLabel: {
    // Your text label styles
  },
});
