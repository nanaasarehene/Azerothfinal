import {StyleSheet, Text, View} from 'react-native';
import React from 'react';
import AddressInputComponent from './AddressInputComponent';
import WithdrawalAmountInput from './WithdrawalAmountInput';

const StyledTextInput = () => {

  const handleAddressChange = (address: string) => {
    console.log('User typed Address:', address);
  };

  const handleNumberInput = (amount: string) => {
    console.log('Number:', amount);
  };

  return (
    <View>
      <AddressInputComponent onChange={handleAddressChange} />
      <WithdrawalAmountInput onNumberChange={handleNumberInput} />
    </View>
  );
};

export default StyledTextInput;
