export const isValidAddress = address => {
  const validateAddress = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d\s,#-]+$/;
  return validateAddress.test(address);
};

export const validateAddress = (input: string): boolean => {
  // Implement your address validation logic here
  const requiredKeywords = ['street', 'city'];
  return requiredKeywords.every(keyword =>
    input.toLowerCase().includes(keyword),
  );
};

export const validateNumber = (input: string): boolean => {
  // Implement your number validation logic here
  const numericValue = parseFloat(input);
  return !isNaN(numericValue) && numericValue >= 0;
};
