import {StyleSheet, Text, View, Image, TouchableOpacity} from 'react-native';
import React from 'react';

export interface LabelTextProps {
  text: string;
}

const TextLabel = () => {
  return (
    <View style={styles.container}>
      <View style={styles.content}>
        <TouchableOpacity>
          <Image
            source={require('../../assets/icons/icon_eye1.png')}
            style={styles.image}
          />
        </TouchableOpacity>
      </View>
      <View style={styles.menuIconWrapper}>
        <TouchableOpacity>
          <Image
            source={require('../../assets/icons/menu.png')}
            style={styles.menuIcon}
          />
        </TouchableOpacity>
      </View>

      <View style={styles.content}>
        <View>
          <Text style={styles.textOne}>공개전송</Text>

          <View style={styles.textTwo}>
            <Text> 나의 공개 자산을 친구의 공개 계정으로 전송해 보세요. </Text>
          </View>
          <View style={styles.iconTwo}>
            <Image
              source={require('../../assets/icons/eye.png')}
              style={styles.icon}
            />
            <Image
              source={require('../../assets/icons/arrow-left.png')}
              style={styles.icon}
            />
            <Image
              source={require('../../assets/icons/eye.png')}
              style={styles.icon}
            />
          </View>
        </View>
      </View>
    </View>
  );
};

export default TextLabel;

const styles = StyleSheet.create({
  container: {
    marginTop: 120,
  },
  content: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
    marginLeft: 10,
  },
  image: {
    width: 48,
    height: 48,
    left: 20,
    marginTop: 10,
  },
  textOne: {
    width: 70,
    height: 24,
    left: 24,
    top: 10,
    color: '#black',
    fontSize: 16,
    fontWeight: 'bold',
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
    marginBottom: 10,
  },
  textTwo: {
    width: 166,
    height: 72,
    left: 24,
    top: 5,
    color: '#black',
    fontSize: 20,
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
  },
  iconTwo: {
    width: 54,
    height: 18,
    left: 24,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    marginBottom: 30,
  },
  icon: {
    width: 18,
    height: 18,
  },
  menuIconWrapper: {
    position: 'absolute',
    top: 20,
    right: 20,
    borderRadius: 25,
    padding: 8,
  },
  menuIcon: {
    width: 24,
    height: 24,
  },
});
