import {StyleSheet, Text, View, Image} from 'react-native';
import React from 'react';

const AssetTransferLabel = () => {
  return (
    <View style={styles.container}>
      <View style={styles.containerContro}> 
      <Text style={styles.title}>전송 후 나의 자산</Text>
      <View style={styles.itemContainer}>
        <View style={styles.iconContainer}>
          <Image
            source={require('../../assets/icons/icon_eye1.png')}
            style={styles.icon}
          />
        </View>
        <View style={styles.textContainer}>
          <Text style={styles.itemTextOne}>공개 계정</Text>
          <Text style={styles.itemTextOne}>100.00 KLAY</Text>
        </View>
      </View>
      <View style={styles.itemContainer}>
        <View style={styles.iconContainer}>
          <Image
            source={require('../../assets/icons/eye-icon2.png')}
            style={styles.icon}
          />
        </View>
        <View style={styles.textContainer}>
          <Text style={styles.itemText}>비밀 계정</Text>
          <Text style={styles.itemText}>80.00 KLAY</Text>
        </View>
      </View>
      </View>
    </View>
  );
};

export default AssetTransferLabel;

const styles = StyleSheet.create({
  container: {
    fontFamily: 'pretendard',
    width: 159,
    height: 76,
    left: 194,
  },
  title: {
    left: 70,
    fontSize: 14,
    fontWeight: 'bold',
    width: 95,
    height: 18,
  },
  itemContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    justifyContent: 'flex-end',
  },
  iconContainer: {
    marginRight: 10,
    left: 1,
    display: 'flex',
  },
  icon: {
    width: 18,
    height: 18,
  },
  textContainer: {
    alignItems: 'center',
    justifyContent: 'space-between',
    flexDirection: 'row',
    textAlign: 'right',
    fontSize: 13,
    fontFamily: 'pretendard',
    width: 125,
    height: 18,
  },
  itemText: {
    alignItems: 'center',
    marginTop: -15,
  },
  itemTextOne: {
    alignItems: 'center',
    color: '#6F64FF',
  },
  containerContro: {
    width: 159,
    height: 76,
  },
});
