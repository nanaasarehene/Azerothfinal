import {StyleSheet, Text, View} from 'react-native';
import React from 'react';

const TextLabelTwo = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.textDecor}>
        나의 KLAY 공개 계정에서 약 0.04 KLAY 수수료가 발생됩니다
      </Text>
    </View>
  );
};

export default TextLabelTwo;

const styles = StyleSheet.create({
  container: {
    width: 296,
    height: 12,
    left: 57,
    fontSize: 12,
    marginTop: 100,
    position: 'relative',
    marginBottom: 40,
  },
  textDecor: {
    color: '#6F64FF',
    fontWeight: 'bold',
  },
});
