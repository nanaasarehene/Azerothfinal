import {StyleSheet, Text, View} from 'react-native';
import React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import AppHeader from '../Header/AppHeader';
import Dashboard from '../Dashboard/Dashboard';
import {createStackContainer} from '@react-navigation/stack';

// eslint-disable-next-line no-undef
const Stack = createStackContainer();

const Navigation = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen
          name="Dashboard"
          component={Dashboard}
          options={{
            // eslint-disable-next-line react/no-unstable-nested-components
            header: ({Navigation, scene}) => (
              <AppHeader
                title="Back"
                item={''}
                navigation={Navigation}
                scene={scene}
                routeLinks="Dashboard"
              />
            ),
          }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default Navigation;

const styles = StyleSheet.create({});
