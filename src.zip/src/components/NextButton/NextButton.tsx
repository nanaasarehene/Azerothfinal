import {StyleSheet, Text, SafeAreaView, TouchableOpacity} from 'react-native';
import React from 'react';

const NextButton = () => {
  return (
    <SafeAreaView>
      <TouchableOpacity onPress={() => {}} style={styles.button}>
        <Text style={styles.buttonText}>확인</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
};

export default NextButton;

const styles = StyleSheet.create({
  button: {
    width: 343,
    height: 52,
    position: 'absolute',
    top: 30,
    left: 16,
    padding: 14,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: '#6F64FF',
  },
  buttonText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#6F64FF',
    textAlign: 'center',
  },
});
