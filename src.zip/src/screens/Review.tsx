import React from 'react';
import {SafeAreaView} from 'react-native';
import NextButton from '../components/NextButton/NextButton';
import AppHeader from '../components/Header/AppHeader';
import Profile from '../components/Profile/Profile';
import TextLabel from '../components/TextLabel/TextLabel';
import StyledTextInput from '../components/StyledTextInput/StyledTextInput';
import TextLabelTwo from '../components/TextLabel/TextLabelTwo';
import AssetTransferLabel from '../components/TextLabel/AssetTransferLabel';

const Review = () => {
  return (
    <SafeAreaView>
      <AppHeader />
      <Profile />
      <TextLabel />
      <StyledTextInput />
      <TextLabelTwo />
      <AssetTransferLabel />
      <NextButton />
    </SafeAreaView>
  );
};
export default Review;
