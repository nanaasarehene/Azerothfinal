import {Dimensions} from 'react-native';
import {
  responsiveScreenHeight,
  responsiveScreenWidth,
  responsiveScreenFontSize,
} from 'react-native-responsive-dimensions';

const FIGMA_WINDOW_WIDTH = 375;
const FIGMA_WINDOW_HEIGHT = 812;

const Windows = {
  width: Dimensions.get('window').width,
  height: Dimensions.get('window').height,
};

export function widthPercentage(width) {
  if (Windows.width <= 375 && Windows.height <= 728) {
    const percentage = (width / FIGMA_WINDOW_WIDTH) * 100;
    return responsiveScreenWidth(percentage);
  }
  return width;
}

export function heightPercentage(height) {
  if (Windows.width <= 375 && Windows.height <= 728) {
    const percentage = (height / FIGMA_WINDOW_HEIGHT) * 100;
    return responsiveScreenHeight(percentage);
  }
  return height;
}

export function fontPercentage(size) {
  if (Windows.width <= 375 && Windows.height <= 728) {
    const percentage = size * 0.135;
    return responsiveScreenFontSize(percentage);
  }
  return size;
}

export const wp = widthPercentage;
export const hp = heightPercentage;
export const fp = fontPercentage;

export default {
  wp: widthPercentage,
  hp: heightPercentage,
  fp: fontPercentage,
  widthPercentage,
  heightPercentage,
  fontPercentage,
};
