/**
 * Author: ksju6561
 */
import {Dimensions, StyleSheet, Platform} from 'react-native';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {getStatusBarHeight} from 'react-native-status-bar-height';
import {getBottomSpace} from 'react-native-iphone-x-helper';
import {useHeaderHeight} from '@react-navigation/elements';

export const getScreenSize = () => {
  return {
    width: Dimensions.get('window').width,
    height: Dimensions.get('window').height,
  };
};

export const getSafeAreaSize = () => {
  const ScreenWidth = Dimensions.get('window').width;
  const ScreenHeight = Dimensions.get('window').height;
  const safeArea = useSafeAreaInsets();
  let headerHeight;

  try {
    headerHeight = useHeaderHeight();
  } catch (error) {
    headerHeight = 0;
  }

  const vh_safeArea = parseInt(ScreenHeight - safeArea.top - safeArea.bottom);
  const vh_statusBar =
    parseInt(ScreenHeight) -
    (Platform.OS === 'android' ? 0 : getStatusBarHeight() + getBottomSpace());
  const vh_headder = ScreenHeight - headerHeight;
  let vw = parseInt(ScreenWidth - safeArea.left - safeArea.right);
  let vh = Math.min(vh_safeArea, vh_statusBar, vh_headder);

  return {
    height: vh,
    width: vw,
  };
};

export const minWidth = (pixel, percent) => {
  const ScreenWidth = Dimensions.get('window').width;
  if (pixel < (ScreenWidth * percent) / 100.0) {
    return pixel;
  } else {
    return (ScreenWidth * percent) / 100.0;
  }
};

export const minHeight = (pixel, percent) => {
  const ScreenHeight = Dimensions.get('window').height;
  if (pixel < (ScreenHeight * percent) / 100.0) {
    return pixel;
  } else {
    return (ScreenHeight * percent) / 100.0;
  }
};

export const Layout = (mw_offset = 20, mh_offset = 8) => {
  const rect = getSafeAreaSize();
  let vw = rect.width,
    vh = rect.height;
  let rate = 1.0;
  let margin_width, margin_top, margin_bottom;

  const car_w = parseInt(vh * (375.0 / 728.0));
  const car_h = parseInt(vw * (728.0 / 375.0));

  if (vw >= 375 && vh >= 728) {
    //가로, 세로 둘다 설계화면보다 큼
    margin_width = parseInt((vw - 375) / 2) + 20;
    margin_top = parseInt((vh - 728) / 2);
    margin_bottom = parseInt((vh - 728) / 2);
    vw = 'auto';
    vh = 728 - 40;
    rate = 1.0;
  } else if (car_w > vw && vh > car_h) {
    //가로 크기에 맞춰 세로를 조정
    margin_width = mw_offset;
    margin_top = parseInt((vh - 728) / 2);
    margin_bottom = parseInt((vh - 728) / 2);
    vw = vw - mw_offset * 2;
    vh = car_h - 40;
    rate = car_h / 728.0;
  } else if (car_h > vh && vw > car_w) {
    //세로 크기에 맞춰 가로를 조정
    margin_width = parseInt((vw - car_w) / 2) + mw_offset / 2;
    margin_top = margin_bottom = mh_offset;
    vh = vh - mh_offset * 2 - 40;
    vw = car_w - mw_offset;
    rate = car_w / 375.0;
  } else {
    //가로, 세로 둘다 설계화면보다 작음
    vw = 'auto';
    vh = vh - mh_offset * 2 - 40;
    margin_top = margin_bottom = mh_offset;
    margin_width = mw_offset;
    rate = car_h / 728.0;
  }

  return {
    marginTop: margin_top ? margin_top : 0,
    marginBottom: margin_bottom ? margin_bottom : 0,
    marginLeft: margin_width ? margin_width : 0,
    marginRight: margin_width ? margin_width : 0,
    width: vw,
    height: vh,
    rate: rate,
  };
};

// Metro UI Colors
export const namedColors = [
  '#99b433',
  '#00a300',
  '#1e7145',
  '#ff0097',
  '#9f00a7',
  '#7e3878',
  '#603cba',
  '#00aba9',
  '#2d89ef',
  '#2b5797',
  '#ffc40d',
  '#e3a21a',
  '#da532c',
  '#ee1111',
  '#b91d47',
];
