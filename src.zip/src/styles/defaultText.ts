import {StyleSheet} from 'react-native';
import {fp} from './responsiveSize';

export default {
    mainFont: StyleSheet.create({
        small: {
            color: 'black',
            fontStyle: 'normal',
            fontSize: fp(8),
        },

        small10: {
            color: 'black',
            fontStyle: 'normal',
            fontSize: fp(10.5),
            fontWeight: '400',
        },
        detail: {
            color: 'black',
            fontStyle: 'normal',
            fontSize: fp(10.5),
            fontWeight: '400',
        },
        main: {
            color: 'black',
            fontStyle: 'normal',
            fontSize: fp(15),
            fontWeight: '400',
        },
        subHeadline: {
            fontStyle: 'normal',
            fontSize: fp(16),
            fontWeight: '300',
            color: 'black',
        },
        subHeadline1: {
            color: 'black',
            fontStyle: 'normal',
            fontSize: fp(18.66),
            fontWeight: '700',
        },
        subHeadline2: {
            color: 'black',
            fontStyle: 'normal',
            fontSize: fp(24.88),
            fontWeight: '700',
        },
        headline: {
            color: 'black',
            fontStyle: 'normal',
            fontSize: fp(24.88),
            fontWeight: '800',
        },
        headline1: {
            fontStyle: 'normal',
            fontSize: fp(28),
            fontWeight: '300',
            color: 'black',
        },
        headline2: {
            color: 'black',
            fontStyle: 'normal',
            fontSize: fp(44.2),
            fontWeight: '800',
        },
        headline3: {
            color: 'black',
            fontStyle: 'normal',
            fontSize: fp(35),
            fontWeight: '800',
        },
    }),
    defaultFontFamily: {
        fontFamily: 'Arial',
    },
    ArialBlack: {
        fontFamily: 'Arial',
        color: 'black',
    },
    ArialWhite: {
        fontFamily: 'Arial',
        color: 'white',
    },
    ArialGray: {
        fontFamily: 'Arial',
        color: '#A5A5A5',
    },
};
