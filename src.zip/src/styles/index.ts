import { Platform, StyleSheet, StatusBar } from 'react-native';
import {
    responsiveHeight,
    responsiveWidth,
    responsiveScreenHeight,
    responsiveFontSize,
} from "react-native-responsive-dimensions";
import { EdgeInsets } from 'react-native-safe-area-context';
import { getStatusBarHeight } from 'react-native-status-bar-height';

const FIGMA_WINDOW_WIDTH = 375;
const FIGMA_WINDOW_HEIGHT = 812;
const FIGMA_WINDOW_ASPECT_RATIO = FIGMA_WINDOW_WIDTH / FIGMA_WINDOW_HEIGHT;

export type DimensionTy = {
    width: number,
    height: number
};

export type EffectiveAppWindowTy = {
    marginLeft: number,
    marginRight: number,
    isWider: boolean,
} & DimensionTy;

var EffectiveAppWindow: EffectiveAppWindowTy = { width: 0, height: 0, marginLeft: 0, marginRight: 0, isWider: true };

function setEffectiveAppWindow(insets?: EdgeInsets) {

    let width = responsiveWidth(100);
    let height = responsiveHeight(100);
    let margin = 0;

    const device_aspect_ratio = responsiveWidth(100) / responsiveHeight(100);

    const isWider = device_aspect_ratio > FIGMA_WINDOW_ASPECT_RATIO;

    if (isWider && (device_aspect_ratio - FIGMA_WINDOW_ASPECT_RATIO > 0.2)) {
        margin = (width - (height * (FIGMA_WINDOW_ASPECT_RATIO + 0.1))) / 2;
        width = width - (margin * 2);
    }

    const StatusBarHeight = Platform.OS === 'ios' ?
        (getStatusBarHeight(true)) ? getStatusBarHeight(true) : 0
        : (StatusBar.currentHeight) ? StatusBar.currentHeight : 0;


    if (Platform.OS === 'android') {
        const android_device_with_onscreen_btn = (responsiveScreenHeight(100) - responsiveHeight(100)) > (StatusBarHeight + 2)
        if (!android_device_with_onscreen_btn) { height = height - StatusBarHeight; }
    } else {
        height = height - (insets ? (insets.bottom + insets.top) : 0);
    }

    EffectiveAppWindow = { width, height, marginLeft: margin, marginRight: margin, isWider };
}

function getEffectiveAppWindow(insets?: EdgeInsets): EffectiveAppWindowTy {
    if (EffectiveAppWindow.width === 0 || EffectiveAppWindow.height === 0) { setEffectiveAppWindow(insets); }
    return EffectiveAppWindow;
}



type ResponsiveDimensionStyleArg = {
    width?: number,
    height?: number,
}

function responsiveDimensionStyle({ width = 0, height = 0 }: ResponsiveDimensionStyleArg) {

    const return_style = {
        width: (width === 0) ? getEffectiveAppWindow().width : (width / FIGMA_WINDOW_WIDTH) * getEffectiveAppWindow().width,
        height: (height / FIGMA_WINDOW_HEIGHT) * responsiveHeight(100),
    };

    return return_style;
}


type ResponsiveMarginStyleArg = {
    margin?: number,
    marginTop?: number,
    marginBottom?: number,
    marginLeft?: number,
    marginRight?: number,
}

function responsiveMarginStyle({
    margin = 0,
    marginTop = 0,
    marginBottom = 0,
    marginLeft = 0,
    marginRight = 0,
}: ResponsiveMarginStyleArg) {

    const [windows_width, windows_height] = [responsiveWidth(100), responsiveHeight(100)];

    const [m_top, m_bottom, m_left, m_right] =
        (margin > 0) ?
            [margin, margin, margin, margin] :
            [marginTop, marginBottom, marginLeft, marginRight];

    const return_style = {
        marginTop: (m_top / FIGMA_WINDOW_HEIGHT) * windows_height,
        marginBottom: (m_bottom / FIGMA_WINDOW_HEIGHT) * windows_height,
        marginLeft: (m_left / FIGMA_WINDOW_WIDTH) * windows_width,
        marginRight: (m_right / FIGMA_WINDOW_WIDTH) * windows_width
    };

    return return_style;
}


function responsiveFontSizeAdjustment(designPxSize: number) {

    const _fsize = getEffectiveAppWindow().isWider ?
        responsiveFontSize(((designPxSize / responsiveScreenHeight(100)) * 100) - 0.2) :
        responsiveFontSize((designPxSize / responsiveScreenHeight(100)) * 100);

    return _fsize;
}



const AzerothColors = {

    AppDefaultBG: 'white',

    Foreground: 'black',
    ValidForeground: '#4CA6FF',
    InvalidForeground: '#FF3263',

    Label: {

        Background: 'rgba(231, 232, 233, 1)',
        Foreground: 'rgba(34, 43, 61, 1)',
        Border: 'rgba(231, 232, 233, 1)',

        Valid: {
            Background: 'rgba(76, 166, 255, 1)',
            Foreground: 'rgba(248, 250, 251, 1)',
            Border: 'rgba(76, 166, 255, 1)'
        },

        Invalid: {
            Background: 'rgba(255, 50, 99, 1)',
            Foreground: 'rgba(248, 250, 251, 1)',
            Border: 'rgba(255, 50, 99, 1)'
        },
    },


    MainButton: {

        Background: '#6F64FF',
        Foreground: 'white',
        Border: '#6F64FF',

        Second: {
            Background: '#ffffff',
            Foreground: '#6F64FF',
            Border: '#6F64FF',
        },

        Disabled: {
            Background: '#E7E8E9', //#DEDFE2',
            Foreground: '#FFFFFF',
            Border: '#E7E8E9',// '#A9A9A9', //'#DEDFE2',
        },

        Valid: {
            Background: 'rgba(76, 166, 255, 1)',
            Foreground: 'rgba(248, 250, 251, 1)',
            Border: 'rgba(76, 166, 255, 1)'
        },

        Invalid: {
            Background: 'rgba(255, 50, 99, 1)',
            Foreground: 'white',
            Border: 'rgba(255, 50, 99, 1)',
        },
    },

    MnemonicWord: {

        Label: {

            Background: '#E7E8E9',
            Foreground: '#222B3D',
            Border: '#E7E8E9',

            Valid: {
                Background: '#4CA6FF',
                Foreground: '#FFFFFF',
                Border: '#4CA6FF',
            },

            Invalid: {
                Background: '#FF3263',
                Foreground: '#F8FAFB',
                Border: '#FF3263',
            },

            UserSelection: {

                Background: '#FFFFFF',
                Foreground: '#A9A9A9',
                Border: '#DEDFE2',

                Active: {
                    Background: '#FFFFFF',
                    Foreground: '#222B3D',
                    Border: '#4CA6FF',
                }
            },
        },

        Button: {
            Background: '#E7E8E9',
            Foreground: '#222B3D',
            Border: '#E7E8E9',

            Disabled: {
                Background: '#FFFFFF',
                Foreground: '#A9A9A9',
                Border: '#E7E8E9',
            }
        }
    }

}


export {
    setEffectiveAppWindow,
    getEffectiveAppWindow,
    responsiveDimensionStyle,
    responsiveMarginStyle,
    responsiveFontSizeAdjustment,
    AzerothColors,
};
